const mongoose = require("mongoose");
const Payment = require("../models/payment");
const Item = require("../models/item");
const Invoice = require("../models/invoice");

/* ---------------- CONSTANTS ---------------- */
const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

const PENDING_STATES = ["scheduled", "saved"];
const VALID_STATES = ["received", "requested", ...PENDING_STATES];

/* ---------------- CONTROLLER ---------------- */
const getVendorDashboardCharts = async (req, res) => {
  try {
    const vendor_id = req.user?.userId;

    if (!mongoose.Types.ObjectId.isValid(vendor_id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid vendor ID"
      });
    }

    /* ---------- YEAR (UTC SAFE) ---------- */
    const year = req.query.year
      ? Number(req.query.year)
      : new Date().getUTCFullYear();

    const startOfYear = new Date(Date.UTC(year, 0, 1, 0, 0, 0));
    const endOfYear = new Date(Date.UTC(year, 11, 31, 23, 59, 59));

    const vendorObjectId = new mongoose.Types.ObjectId(vendor_id);

    /* =====================================================
       1. PAYMENTS + TAX (EXCLUDE CANCELED)
       ===================================================== */
    const paymentsRaw = await Payment.aggregate([
      {
        $match: {
          vendor_id: vendorObjectId,
          status: "active",
          payment_state: { $in: VALID_STATES }, // 🚀 FIX
          createdAt: { $gte: startOfYear, $lte: endOfYear }
        }
      },
      {
        $lookup: {
          from: "invoices",
          localField: "invoice_id",
          foreignField: "_id",
          as: "invoice"
        }
      },
      { $unwind: "$invoice" },
      {
        $project: {
          month: { $month: "$createdAt" },
          amount: "$invoice_amount",
          tax: { $ifNull: ["$invoice.total_tax_amount", 0] },
          bucket: {
            $cond: [
              { $eq: ["$payment_state", "received"] },
              "received",
              {
                $cond: [
                  { $eq: ["$payment_state", "requested"] },
                  "requested",
                  "pending"
                ]
              }
            ]
          }
        }
      }
    ]);

    /* =====================================================
       2. SUMMARY (AMOUNT + TAX)
       ===================================================== */
    const summary = paymentsRaw.reduce(
      (acc, curr) => {
        acc[curr.bucket].amount += curr.amount;
        acc[curr.bucket].tax += curr.tax;
        return acc;
      },
      {
        requested: { amount: 0, tax: 0 },
        pending: { amount: 0, tax: 0 },
        received: { amount: 0, tax: 0 }
      }
    );

    /* =====================================================
       3. PAYMENTS BY MONTH
       ===================================================== */
    const paymentData = MONTHS.map((month, idx) => {
      const monthNum = idx + 1;

      const monthPayments = paymentsRaw.filter(
        p => p.month === monthNum
      );

      return {
        month,
        requested: monthPayments
          .filter(p => p.bucket === "requested" || p.bucket === "pending")
          .reduce((s, p) => s + p.amount, 0),
        received: monthPayments
          .filter(p => p.bucket === "received")
          .reduce((s, p) => s + p.amount, 0)
      };
    });

    /* =====================================================
       4. PAYMENT STATUS (COUNT)
       ===================================================== */
    const paymentStatusData = {
      requested: paymentsRaw.filter(p => p.bucket === "requested").length,
      pending: paymentsRaw.filter(p => p.bucket === "pending").length,
      received: paymentsRaw.filter(p => p.bucket === "received").length
    };

    /* =====================================================
       5. ITEMS BY CATEGORY
       ===================================================== */
    const itemsCategoryRaw = await Item.aggregate([
      {
        $match: {
          vendor_id: vendorObjectId,
          status: true
        }
      },
      {
        $group: {
          _id: { $toLower: "$category" },
          count: { $sum: 1 }
        }
      }
    ]);

    const itemsByCategory = {
      product: itemsCategoryRaw.find(i => i._id === "product")?.count || 0,
      service: itemsCategoryRaw.find(i => i._id === "service")?.count || 0,
      expense: itemsCategoryRaw.find(i => i._id === "expense")?.count || 0
    };

    /* =====================================================
       6. ITEMS ACTIVITY
       ===================================================== */
    const itemsActivityRaw = await Item.aggregate([
      {
        $match: {
          vendor_id: vendorObjectId,
          status: true,
          createdAt: { $gte: startOfYear, $lte: endOfYear }
        }
      },
      {
        $project: {
          createdMonth: { $month: "$createdAt" },
          isModified: {
            $cond: [{ $ne: ["$createdAt", "$updatedAt"] }, 1, 0]
          }
        }
      },
      {
        $group: {
          _id: "$createdMonth",
          added: { $sum: 1 },
          modified: { $sum: "$isModified" }
        }
      }
    ]);

    const itemsActivityData = MONTHS.map((month, idx) => {
      const monthNum = idx + 1;
      const data = itemsActivityRaw.find(m => m._id === monthNum);

      return {
        month,
        added: data?.added || 0,
        modified: data?.modified || 0
      };
    });

    /* =====================================================
       RESPONSE
       ===================================================== */
    return res.status(200).json({
      success: true,
      message: "Dashboard data retrieved successfully",
      data: {
        summary: {
          requested: {
            amount: Number(summary.requested.amount.toFixed(2)),
            tax: Number(summary.requested.tax.toFixed(2))
          },
          pending: {
            amount: Number(summary.pending.amount.toFixed(2)),
            tax: Number(summary.pending.tax.toFixed(2))
          },
          received: {
            amount: Number(summary.received.amount.toFixed(2)),
            tax: Number(summary.received.tax.toFixed(2))
          }
        },
        paymentData,
        paymentStatusData,
        itemsByCategory,
        itemsActivityData
      }
    });

  } catch (error) {
    console.error("Dashboard Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to load dashboard"
    });
  }
};

module.exports = {
  getVendorDashboardCharts
};
