// controllers/webhook-controllers.js
const crypto = require("crypto");
const { createOrdertoTransferAmount } = require("../utils/razorpay/razorpay-helpers");
const { updateClient } = require("../utils/EmailUtils");
const { updatePayments } = require("./payment-controllers");
const { updateAlerts } = require("./alert-controllers");
const { markInvoiceInactive } = require("./invoice-controllers");
const { sendRenewalSuccessfulEmail } = require("../utils/EmailUtils");

const SubscriptionPayment = require("../models/subscriptionPayment");
const User = require("../models/users");
const Alert = require("../models/alerts");



const formatDate = (date) => {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
};

// function to update alerts when bank status updated
const updateAlertsOnKyCResponse = async (payloadData) => {
  try {
    if (!payloadData?.event || !payloadData?.payload?.product?.entity) {
      return;
    }

    const entity = payloadData.payload.product.entity;
    const event = payloadData.event;

    const razorpayAccountId = entity.account_id;
    if (!razorpayAccountId) return;

    /* ---------------- EVENT → STATUS ---------------- */
    const eventStatusMap = {
      "product.route.activated": "activated",
      "product.route.rejected": "rejected",
      "product.route.under_review": "under_review",
      "product.route.needs_clarification": "needs_clarification"
    };

    const status = eventStatusMap[event];
    if (!status) return;

    /* ---------------- FETCH USER ---------------- */
    const user = await User.findOne({
      razorpay_account_id: razorpayAccountId
    }).select("_id razorpay_account_status");

    if (!user) {
      console.warn(
        `Alert skipped: No user for Razorpay account ${razorpayAccountId}`
      );
      return;
    }

    /* ---------------- IDEMPOTENCY GUARD ---------------- */
    // If alert already exists for this status, do nothing
    const existingAlert = await Alert.findOne({
      vendor_id: user._id,
      reference_table: "razorpay_kyc",
      reference_status: status
    });

    if (existingAlert) return;

    /* ---------------- MESSAGE BUILD ---------------- */
    const reason =
      entity.reason ||
      entity.failure_reason ||
      "No reason provided";

    const description =
      entity.notes?.description ||
      entity.notes?.comment ||
      "";

    const eventMessages = {
      activated: "Account activated: You can start sending payments now!",
      rejected: `Account rejected: ${reason} ${description}`,
      under_review: `Account under review: ${reason} ${description}`,
      needs_clarification: `Additional KYC clarification required: ${reason} ${description}`
    };

    const alertText = eventMessages[status];
    if (!alertText) return;

    /* ---------------- CREATE ALERT ---------------- */
    await Alert.create({
      alert_text: alertText,
      reference_table: "razorpay_kyc",
      reference_status: status,
      vendor_id: user._id,
      createdAt: new Date()
    });

  } catch (error) {
    // ⚠️ DO NOT throw — webhook must stay stable
    console.error("updateAlertsOnKyCResponse error:", error);
  }
};

// previously handleSuccessfulPayment
const handlePaymentSuccessOnSubscription = async (payload) => {
  try {
    console.log('got here on success')
    const payment =
      payload?.payload?.payment?.entity ||
      payload?.payload?.order?.entity;

    if (!payment) {
      throw new Error("Invalid Razorpay webhook payload");
    }

    const orderId = payment.order_id || payment.id;
    const paymentId = payment.id;

    if (!orderId || !paymentId) {
      throw new Error("Missing order_id or payment_id");
    }

    /* ---------------- PAYMENT IDEMPOTENCY ---------------- */
    const subscriptionPayment = await SubscriptionPayment.findOneAndUpdate(
      {
        order_id: orderId,
        status: "pending"
      },
      {
        status: "paid"
      },
      { new: true }
    );

    // Already processed
    if (!subscriptionPayment) return;

    /* ---------------- USER FETCH ---------------- */
    const user = await User.findById(subscriptionPayment.user_id);
    if (!user) {
      throw new Error("User not found for subscription");
    }

    /* ---------------- EXPIRY CALCULATION ---------------- */
    const now = new Date();

    // IMPORTANT: extend from existing expiry if active
    const baseDate =
      user.subscription_expiry && user.subscription_expiry > now
        ? new Date(user.subscription_expiry)
        : now;

    const expiry = new Date(baseDate);

    if (user.plan_interval === "yearly") {
      expiry.setFullYear(expiry.getFullYear() + 1);
    } else {
      expiry.setMonth(expiry.getMonth() + 1);
    }

    /* ---------------- USER UPDATE ---------------- */
    await User.findByIdAndUpdate(user._id, {
      is_subscribed: true,
      free_trial: false,

      subscription_expiry: expiry,
      plan_started_at: now,

      subscription_status: "active",
      current_plan: "pro",

      subscription_details: {
        provider: "razorpay",
        order_id: orderId,
        payment_id: paymentId,
        auto_renew: false
      }
    });

  } catch (error) {
    console.error("handlePaymentSuccessOnSubscription error:", error);
    throw error;
  }
};


// function to handle failure on subscription failure
const handleExpiredSubsPayment = async (payload) => {
  try {
    const paymentLink = payload?.payload?.payment_link?.entity;
    if (!paymentLink) return;

    const orderId = paymentLink?.order_id;
    if (!orderId) return;

    await SubscriptionPayment.findOneAndUpdate(
      {
        order_id: orderId,
        status: "pending"
      },
      {
        status: "failed"
      }
    );

  } catch (error) {
    console.error("handleExpiredSubsPayment error:", error);
    throw error;
  }
};

// ----------------------------------- controllers -----------------------------------

// Transfers amount to linked account on successful payment
const transferAmoutToLinkedAccWebhook = async (req, res, next) => {
  try {
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET1;
    const payload = req.body;
    const signature = req.headers["x-razorpay-signature"];

    // Validate the webhook signature
    const crypto = require("crypto");
    const expectedSignature = crypto
      .createHmac("sha256", webhookSecret)
      .update(JSON.stringify(payload))
      .digest("hex");

    if (signature !== expectedSignature) {
      return res.status(400).send("Invalid signature");
    }

    // Check if payment was successful
    if (payload.event === "payment.captured") {
      const payment = payload?.payload?.payment?.entity;
      if (!payment) {
        return res.status(400).send("Invalid payload format");
      }

      const appType = payment.notes?.app;
      if (appType !== "WON_BILLS") {
        return res.status(200).send("Payment not related to WON_BILLS, ignoring.");
      }

      const paymentId = payment.id;
      const clientName = payment.notes?.client_name;
      const linkedAccountId = payment.notes?.vendor_rzp_linked_account_id;
      const amount = payment.notes?.total_amount / 100;
      const currency = payment.notes?.currency;
      const Fees = payment.notes?.totalFee;
      const AmountToTransfer = amount - Fees;
      const PurchaseOrderID = payment.notes?.purchase_order_id;
      const VendorId = payment.notes?.vendor_id;
      const invoice_id = payment.notes?.invoice_id;

      const Order = createOrdertoTransferAmount(
        linkedAccountId,
        amount,
        AmountToTransfer,
        currency,
        PurchaseOrderID,
        paymentId
      )
        .then(() => {
          // AFTER TRANSFER IS SUCCESSFUL, UPDATE THE ALERTS TABLE
          updatePayments(PurchaseOrderID);
          updateAlerts(PurchaseOrderID, clientName, amount, VendorId);
          updateClient(PurchaseOrderID, amount, VendorId, Order.id);
          markInvoiceInactive(invoice_id);
        })
        .catch((error) => {
          console.error("Error during transfer:", error.message);
        });
    }

    res.status(200).send("Webhook received");
  } catch (error) {
    console.error("Error handling webhook:", error);
    res.status(500).send("Internal Server Error");
  }
};

// handles when subcription paymnet is success
const subscriptionWebhook = async (req, res) => {
  try {
    /* =====================================================
       1. BASIC VALIDATION
    ===================================================== */
    const signature = req.headers["x-razorpay-signature"];
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET2;

    if (!signature || !webhookSecret) {
      return res.status(400).json({
        success: false,
        message: "Missing webhook signature or secret",
      });
    }

    if (!req.rawBody) {
      console.error("Webhook rawBody missing");
      return res.status(400).json({
        success: false,
        message: "Raw body not available",
      });
    }

    /* =====================================================
       2. SIGNATURE VERIFICATION (CRITICAL)
    ===================================================== */
    const expectedSignature = crypto
      .createHmac("sha256", webhookSecret)
      .update(req.rawBody) // MUST be raw buffer
      .digest("hex");

    if (signature !== expectedSignature) {
      console.error("Invalid Razorpay webhook signature");
      return res.status(400).json({
        success: false,
        message: "Invalid Webhook Signature",
      });
    }

    /* =====================================================
       3. EVENT HANDLING
    ===================================================== */
    const event = req.body?.event;

    if (!event) {
      return res.status(200).json({ success: true });
    }

    switch (event) {
      /* -------- PAYMENT SUCCESS -------- */
      case "payment.captured":
      case "order.paid":
      case "payment_link.paid":
        await handlePaymentSuccessOnSubscription(req.body);
        break;

      /* -------- PAYMENT EXPIRED / FAILED -------- */
      case "payment_link.expired":
      case "payment.failed":
        await handleExpiredSubsPayment(req.body);
        break;

      /* -------- IGNORE OTHER EVENTS -------- */
      default:
        // Razorpay expects 2xx even if event is not handled
        return res.status(200).json({ success: true });
    }

    /* =====================================================
       4. ACKNOWLEDGE WEBHOOK
    ===================================================== */
    return res.status(200).json({
      success: true,
      message: "Webhook processed successfully",
    });

  } catch (error) {
    console.error("Subscription webhook processing error:", error);

    // Razorpay retries on non-2xx → return 200 to avoid infinite retries
    return res.status(200).json({
      success: true,
    });
  }
};


// triggers when razorpay account status changed
const LinkedAccountStatusUpdateWebhook = async (req, res) => {
  try {
    const signature = req.headers["x-razorpay-signature"];
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET3;

    /* ---------------- SIGNATURE VERIFICATION ---------------- */
    const expectedSignature = crypto
      .createHmac("sha256", webhookSecret)
      .update(req.body) // RAW BODY (Buffer)
      .digest("hex");

    if (signature !== expectedSignature) {
      return res.status(400).send("Invalid signature");
    }

    const payload = JSON.parse(req.body.toString());
    const entity = payload?.payload?.product?.entity;

    const accountId = entity?.account_id;
    if (!accountId) {
      return res.status(400).send("Missing account_id");
    }

    /* ---------------- EVENT → STATUS MAP ---------------- */
    const eventStatusMap = {
      "product.route.activated": "activated",
      "product.route.rejected": "rejected",
      "product.route.under_review": "under_review",
      "product.route.needs_clarification": "needs_clarification"
    };

    const newStatus = eventStatusMap[payload.event];
    if (!newStatus) {
      console.log("Unhandled Razorpay event:", payload.event);
      return res.status(200).send("Unhandled event");
    }

    /* ---------------- DB IS SOURCE OF TRUTH ---------------- */
    const user = await User.findOne({
      razorpay_account_id: accountId
    });

    if (!user) {
      // Not created by this platform → ignore safely
      return res.status(200).send("Ignored");
    }

    /* ---------------- PREVENT STATUS REGRESSION ---------------- */
    const currentStatus = user.razorpay_account_status || "failed";

    if (
      STATUS_PRIORITY[newStatus] <=
      STATUS_PRIORITY[currentStatus]
    ) {
      return res.status(200).send("Stale event ignored");
    }

    /* ---------------- UPDATE STATUS ---------------- */
    user.razorpay_account_status = newStatus;
    await user.save();

    /* ---------------- OPTIONAL ALERTS ---------------- */
    await updateAlertsOnKyCResponse(payload);

    return res.status(200).send("Webhook processed");
  } catch (error) {
    console.error("Webhook processing error:", error);
    return res.status(500).send("Server error");
  }
};



module.exports = {
  transferAmoutToLinkedAccWebhook,
  subscriptionWebhook,
  LinkedAccountStatusUpdateWebhook
}