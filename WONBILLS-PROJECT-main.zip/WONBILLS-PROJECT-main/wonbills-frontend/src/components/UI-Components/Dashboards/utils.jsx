export const paymentData = [
  { month: "Jan", requested: 120000, received: 95000 },
  { month: "Feb", requested: 98000, received: 87000 },
  { month: "Mar", requested: 145000, received: 130000 },
  { month: "Apr", requested: 110000, received: 102000 },
  { month: "May", requested: 160000, received: 150000 },
  { month: "Jun", requested: 140000, received: 128000 },
  { month: "Jul", requested: 155000, received: 149000 },
  { month: "Aug", requested: 170000, received: 160000 },
  { month: "Sep", requested: 130000, received: 118000 },
  { month: "Oct", requested: 165000, received: 158000 },
  { month: "Nov", requested: 175000, received: 168000 },
  { month: "Dec", requested: 190000, received: 182000 }
];

export const itemsActivityData = [
  { month: "Jan", added: 12, modified: 5 },
  { month: "Feb", added: 18, modified: 9 },
  { month: "Mar", added: 10, modified: 14 },
  { month: "Apr", added: 22, modified: 11 },
  { month: "May", added: 16, modified: 8 },
  { month: "Jun", added: 20, modified: 15 },
  { month: "Jul", added: 14, modified: 6 },
  { month: "Aug", added: 19, modified: 10 },
  { month: "Sep", added: 11, modified: 7 },
  { month: "Oct", added: 23, modified: 13 },
  { month: "Nov", added: 17, modified: 9 },
  { month: "Dec", added: 25, modified: 16 }
];
