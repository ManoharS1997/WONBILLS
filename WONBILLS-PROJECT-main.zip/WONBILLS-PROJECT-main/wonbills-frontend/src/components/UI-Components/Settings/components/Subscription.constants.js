export const PRICING = {
  monthly: 999,
  yearly: 9999,
};

export const PRO_FEATURES = [
  "Unlimited bill tracking",
  "Advanced analytics & reports",
  "Priority support",
  "Export & integrations",
  "Custom branding",
];

export const YEARLY_SAVING = PRICING.monthly * 12 - PRICING.yearly;