export const initialSigninState = {
    identifier: { value: "", isValid: false },
    type: { value: "phone", isValid: true },
    otp: { value: "", isValid: false }
}