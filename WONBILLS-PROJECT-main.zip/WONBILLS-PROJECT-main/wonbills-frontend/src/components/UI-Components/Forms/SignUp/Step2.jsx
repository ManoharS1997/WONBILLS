import React, { useMemo, useState } from 'react'
import { InputTag, ReactSelect } from '../../../UI-Elements/Input-Elements/Input-tags'
import { Link } from 'react-router-dom';
import { Country, State } from "country-state-city";
import { companyTypes, industryTypes, allSubCategories } from '../../../../shared/ConstData';
import Modal from '../../../UI-Elements/modals/Modal';
import TermsConditions from '../../Others/TermsConditions';

const Step2 = ({ userState, setUserState, postCodeLoading = false }) => {
  const [subCategory, setSubCategory] = useState([])
  const [openTerms, setTermsOpen] = useState(false);

  const onCategoryChange = (category) => {
    setSubCategory(allSubCategories[category] || []);
    setUserState('company_subcategory', null, true)
  }

  const countryOptions = useMemo(() => {
    return Country.getAllCountries().map((c) => ({
      value: c.isoCode,
      label: c.name,
    }));
  }, []);

  const stateOptions = useMemo(() => {
    if (!userState.country.value) return [];
    return State.getStatesOfCountry(userState.country.value).map((s) => ({
      value: s.isoCode,
      label: s.name,
    }));
  }, [userState.country.value]);

  return (
    <div className="flex flex-col">
      <h2 className="text-md font-semibold ">Business Details</h2>
      <p className='text-xs text-gray-400 mb-4'>Build Your Profile, Build Your Success!</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-x-3 pr-2 lg:p-0">

        <InputTag
          id="company_name"
          label="Company Name *"
          value={userState?.company_name?.value}
          onChangeVal={(val, isValid) => setUserState('company_name', val, isValid)}
        />
        <InputTag
          id="company_registration_no"
          label="Registration No *"
          value={userState?.company_reg_number?.value}
          onChangeVal={(val, isValid) => setUserState('company_reg_number', val, isValid)}
        />
        <InputTag
          id="gst_no"
          label="GST No *"
          value={userState?.company_tax_number?.value}
          onChangeVal={(val, isValid) => setUserState('company_tax_number', val, isValid)}
        />

        <ReactSelect
          id="business_type"
          label="Business Type *"
          options={companyTypes}
          value={companyTypes?.find((opt) => opt.value === userState?.company_type?.value)}
          onChange={(val, isValid) => setUserState('company_type', val, isValid)}

        />
        <ReactSelect
          id="category"
          label="Category *"
          options={industryTypes}
          value={industryTypes?.find((opt) => opt.value === userState?.company_category?.value)}
          onChange={(val, isValid) => {
            setUserState('company_category', val, isValid)
            onCategoryChange(val)
          }}
        />

        {userState?.company_category?.value === 'others' ? (
          <InputTag
            id='sub_category'
            label="Sub Category *"
            value={userState?.company_subcategory?.value}
            onChangeVal={(val, isValid) => setUserState('company_subcategory', val, isValid)}
          />
        ) : (
          <ReactSelect
            id="sub_category"
            label="Sub Category *"
            options={subCategory}
            value={subCategory?.find((opt) => opt.value === userState?.company_subcategory?.value)}
            onChange={(val, isValid) => setUserState('company_subcategory', val, isValid)}
          />
        )}


        <ReactSelect
          id="country"
          label="Country *"
          options={countryOptions}
          value={countryOptions.find(
            (opt) => opt.value === userState.country.value
          ) || null}
          onChange={(val, isValid) => {
            setUserState("country", val, isValid);
            setUserState("state", "", false); // Reset state
          }}
        />
        <InputTag
          id='pincode'
          label="Zip Code *"
          value={userState?.postcode?.value}
          onChangeVal={(val, isValid) => setUserState('postcode', val.replace(/\D/g, ""), isValid)}
          loading={postCodeLoading}
        />

        <InputTag
          id="state"
          label="State *"
          value={userState?.state?.value}
          readonly
        />

        <InputTag
          id="city"
          label="City *"
          value={userState?.city?.value}
          onChangeVal={(val, isValid) => setUserState('city', val, isValid)}
          readonly
        />

      </div>

      <label className="flex items-center gap-2 text-sm ml-3 cursor-pointer select-none">
        <input
          type="checkbox"
          checked={Boolean(userState?.agreed_to_terms?.value)}
          onChange={(e) =>
            setUserState("agreed_to_terms", e.target.checked, true)
          }
          className="
                        h-3 w-3
                        accent-blue-500
                        cursor-pointer
                        focus:outline-none focus:ring-2 focus:ring-blue-400
                        "
        />

        <span>
          I agree to the{" "}
          <button
            type="button"
            onClick={() => setTermsOpen(true)}
            className="
                            underline text-blue-500 hover:text-blue-600
                            focus:outline-none focus:ring-blue-400
                        "
          >
            Terms & Conditions
          </button>
        </span>
      </label>


      <Modal
        isOpen={openTerms}
        onClose={() => setTermsOpen(false)}
        title="Terms & Privacy Policy"
      >
        <TermsConditions />
      </Modal>
    </div>
  );
};


export default React.memo(Step2);