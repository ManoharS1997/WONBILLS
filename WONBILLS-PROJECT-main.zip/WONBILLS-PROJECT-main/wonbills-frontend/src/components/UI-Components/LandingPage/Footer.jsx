import React from 'react';
import { FaFacebook, FaInstagram, FaLinkedin, FaYoutube } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const SocialMedia = [
    {
        name: "Instagram",
        url: "https://www.instagram.com/_nowitservices_/profilecard/",
        icon: <FaInstagram />
    },
    {
        name: "LinkedIn",
        url: "https://www.linkedin.com/company/nowitservices/",
        icon: <FaLinkedin />
    },
    {
        name: "YouTube",
        url: "https://www.youtube.com/channel/UCcGdytqPFKcM_iASD0mVGbA",
        icon: <FaYoutube />
    }, {
        name: "Facebook",
        url: "https://www.facebook.com/NowITServices?_rdr",
        icon: <FaFacebook />
    },
]

const ISO = () => {
    return (
        <div className="w-full flex flex-col items-center justify-center py-10 gap-3">
            <img
                src="https://res.cloudinary.com/dca9sij3n/image/upload/f_auto,q_auto/fuubxxty3ih0f9wmjkdr"
                alt="ISO"
                className="h-30 w-30 object-contain"
            />
            <p className='text-xs font-semibold'>Powered By NOWIT SERVICES Pvt Ltd</p>
        </div>
    );
};

const Company = () => {
    return (
        <div className="w-full flex flex-col gap-3">
            <h3 className="font-bold text-lg">Company</h3>

            <ul className="pl-5 flex flex-col gap-1 list-disc text-gray-600">
                {[
                    { label: "Terms & Conditions", to: "/terms-conditions/policy" },
                    { label: "Privacy Policy", to: "/terms-conditions/policy" },
                    { label: "Refund Policy", to: "/terms-conditions/policy" },
                ].map((item) => (
                    <li key={item.to}>
                        <Link
                            to={item.to}
                            className="text-blue-400 hover:text-black hover:underline transition"
                        >
                            {item.label}
                        </Link>
                    </li>
                ))}

                <li>
                    <a
                        href="https://www.youtube.com/playlist?list=PLWYlyy6Uq5rn7Mr7lvSLNd8FPJh8sQ-B3"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:text-black hover:underline transition"
                    >
                        Tutorials
                    </a>
                </li>
            </ul>
        </div>
    );
};

const ContactInfo = () => {
    return (
        <div>
            <h3 className="font-bold text-lg mb-2">Contact Info</h3>
            <div>
                <p className='text-md font-semibold text-gray-800'>Address</p>
                <span className='text-gray-400'>
                    17-6-284-1, Uma Shankar Nagar, Vijayawada, Andhra Pradesh,
                    India
                </span>
            </div>

            <div>
                <p className='text-md font-semibold text-gray-800'>Phone</p>
                <span className='text-gray-400'>
                    +91 7893536373
                </span>
            </div>
            <div>
                <p className='text-md font-semibold text-gray-800'>Email</p>
                <a className='text-gray-400' href="mailto:contact.us@nowitservices.com">
                    contact.us@nowitservices.com
                </a>
            </div>
        </div>
    )
}

const SocialMediaLinks = () => {
    return (
        <div className='flex w-full flex-col '>
            <h3 className="font-bold text-lg mb-2">Social Media</h3>
            <div className='grid grid-cols-4 gap-x-2 p-7 m-auto'>
                {SocialMedia.map((media) => (
                    <span key={media.name} className='bg-gray-300 h-10 w-10 flex items-center justify-center rounded-2xl'>
                        <a
                            href={media.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-400 hover:text-black text-2xl hover:underline transition"
                        >
                            {media.icon}
                        </a>
                    </span>
                ))}
            </div>
        </div>
    )
}



const Footer = () => {
    return (
        <footer className="w-full mt-10 bg-gray-200 rounded-t-3xl pt-4">
            <div className="
        w-full
        grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4
        gap-6
        px-6
      ">
                <ISO />
                <Company />
                <ContactInfo />
                <SocialMediaLinks />
            </div>

            <hr className="border-dashed border-gray-600 mt-6" />

            <p className="text-center text-gray-600 text-sm py-4">
                © 2024 Wonbills. All rights reserved.
            </p>
        </footer>
    );
};



export default Footer;
