import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';

const texts = ["Design!", "Customize!", "Rock!"];


const Hero = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) =>
        prev === texts.length - 1 ? 0 : prev + 1
      );
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      {/* TOP SECTION */}
      <div className="w-full flex flex-col lg:flex-row px-4 sm:px-10 lg:px-15">
        <div className="w-full lg:w-1/4 flex flex-col items-center justify-center py-6">
          <img
            src="https://wonbillsnew.s3.ap-south-1.amazonaws.com/Untitled+design.png"
            alt="Hero"
            className="h-20 sm:h-24 w-auto"
          />
          <p className="font-caveat text-xl sm:text-2xl">
            <strong className="text-2xl sm:text-3xl">10X</strong> Faster
          </p>
          <p className="font-caveat text-xl sm:text-2xl">
            <strong className="text-2xl sm:text-3xl">10X</strong> Safer & Secure
          </p>
        </div>

        <div className="w-full lg:w-3/4 flex flex-col justify-center gap-3 py-6">
          <h2 className="text-4xl sm:text-5xl lg:text-7xl font-bold font-caveat">
            Invoicing made fun :
            <span className="relative inline-block ml-2 text-[#4B4AEF]">
              {texts[currentIndex]}
            </span>
          </h2>

          <p className="font-sour-gummy text-base sm:text-lg text-gray-600">
            Meet your B2B invoicing partner! Design sleek invoices, customize them
            your way, and enjoy stress-free billing.
          </p>
        </div>
      </div>

      {/* CTA SECTION */}
      <div className="w-full flex flex-col lg:flex-row px-4 sm:px-10 lg:px-15">
        <div className="w-full lg:w-1/2 flex flex-col items-center justify-center py-8 gap-3">
          <p className="font-caveat text-2xl sm:text-3xl font-bold text-center">
            Sign Up for Free & <br /> Start Billing in Style!
          </p>
          <Link
            to="/signup"
            className="font-sour-gummy px-7 py-3 bg-[#FFCA1D] text-white rounded-2xl"
          >
            Get Started
          </Link>
        </div>

        <div className="w-full lg:w-1/2 flex justify-center py-4">
          <img
            src="https://res.cloudinary.com/dca9sij3n/image/upload/v1767244258/b2b_qxz8wf.png"
            alt="Billing"
            className="max-h-80 sm:max-h-96 object-contain"
          />
        </div>
      </div>
    </div>
  );
};


export default Hero
