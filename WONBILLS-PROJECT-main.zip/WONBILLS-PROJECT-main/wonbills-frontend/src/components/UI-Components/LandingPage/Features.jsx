import React from 'react'

const FeaturesData = [
    {
        title: " Taxing Made Relaxing with GST-Compliant Invoices",
        description: `Effortlessly manage GST-compliant billing with WON Bills. Generate accurate invoices, ensure seamless tax compliance,
                       and speed up payments—all in one platform designed for your business growth.`,
        imgUrl: 'https://res.cloudinary.com/dca9sij3n/image/upload/f_auto,q_auto/dgonckfa4xtgfg8huiwg'
    },
    {
        title: "No More Late Payments: Automate Reminders & Boost Collections!",
        description: `Say goodbye to missed payments! Automate your payment reminders and streamline collections,
                                        making cash flow smoother and faster than ever!`,
        imgUrl: 'https://res.cloudinary.com/dca9sij3n/image/upload/v1732342052/hhuuypnx5ychj4l10ayt.png'
    },
    {
        title: "Smarter Business at a Glance: Power-Packed Dashboards!",
        description: `Get the full picture with our comprehensive dashboards! Track performance, manage finances,
                                        and make smarter decisions—all in one place.`,
        imgUrl: 'https://res.cloudinary.com/dca9sij3n/image/upload/f_auto,q_auto/vj8nzalcodqrno2uxkwv'
    },
    {
        title: " Easy Pay, Easy Life: Seamless Payment Gateway Integration!",
        description: `Unlock smooth transactions with our Payment Gateway Integration. Connect easily, accept payments hassle-free,
                                        and keep your business buzzing without a hitch!`,
        imgUrl: 'https://res.cloudinary.com/dca9sij3n/image/upload/f_auto,q_auto/aemwhbx2ao4wkdgypf7h'
    },
    {
        title: "Global Payments Made Simple: Multi-Currency Support!",
        description: `Expand your horizons with seamless multi-currency support. Send and receive payments in any currency,
                                        making global transactions effortless and stress-free!`,
        imgUrl: 'https://res.cloudinary.com/dca9sij3n/image/upload/f_auto,q_auto/zxiud6ywdrk8duyyrrch'
    },
    {
        title: "Click, Send, Done!  Invoice template as vector",
        description: `Discover the ultimate e-invoicing solution for streamlined billing and faster payments. Simplify GST compliance,
                                        generate accurate invoices, and enhance your financial workflow—all in one powerful platform. Start your journey to hassle-free invoicing now!`,
        imgUrl: 'https://res.cloudinary.com/dca9sij3n/image/upload/f_auto,q_auto/pbzfh8r6i1xng9ejflnr'
    },

]

const Features = () => {
  return (
    <div className="w-full">
      {FeaturesData.map((feature, index) => (
        <div
          key={index}
          className={`
            flex flex-col md:flex-row
            px-4 sm:px-10 lg:px-15
            py-8 gap-6
            ${index % 2 !== 0 ? "md:flex-row-reverse" : ""}
          `}
        >
          <div className="w-full md:w-1/3 flex justify-center">
            <img
              src={feature.imgUrl}
              alt={feature.title}
              className="max-h-72 object-contain"
            />
          </div>

          <div className="w-full md:w-2/3">
            <h3 className="text-2xl sm:text-4xl font-bold mb-3 font-caveat">
              {feature.title}
            </h3>
            <p className="text-gray-500 text-lg sm:text-2xl font-sour-gummy">
              {feature.description}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};



export default Features
