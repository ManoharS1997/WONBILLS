import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
    return (
        <header
            className="
            h-auto sm:h-[7vh]
            px-4 sm:px-6
            py-2
            flex sm:flex-row
            items-center justify-between
            gap-2
            sticky top-0 z-50
            bg-blue-50
            border-b border-blue-200
        "
        >
            <h1 className="text-blue-700 text-2xl sm:text-3xl font-caveat">
                Welcome to Wonbills
            </h1>

            <div className="flex gap-3">
                <Link
                    to="/signup"
                    className="px-4 sm:px-5 py-1.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition"
                >
                    Register
                </Link>

                <Link
                    to="/signin"
                    className="px-4 sm:px-5 py-1.5 border border-blue-600 text-blue-600 rounded-xl font-semibold hover:bg-blue-100 transition"
                >
                    Sign In
                </Link>
            </div>
        </header>
    );
};


export default Header;
