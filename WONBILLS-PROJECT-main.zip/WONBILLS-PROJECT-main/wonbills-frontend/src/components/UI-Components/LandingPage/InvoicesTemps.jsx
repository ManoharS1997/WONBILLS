import React from 'react'
const TempsList = [
    { name: "temp1", imgUrl: "https://res.cloudinary.com/dkk0hqyat/image/upload/v1775471043/template1_btc7kt.png" },
    { name: "temp2", imgUrl: "https://res.cloudinary.com/dkk0hqyat/image/upload/v1775471043/template2_bxlcyb.png" },
    { name: "temp3", imgUrl: "https://res.cloudinary.com/dkk0hqyat/image/upload/v1775471043/template3_hyr7fi.png" },
]

const InvoicesTemps = () => {
   return (
  <div className="w-full flex justify-center">
    <div
      className="
        grid
        grid-cols-1
        sm:grid-cols-2
        md:grid-cols-3
        lg:grid-cols-[repeat(auto-fit,minmax(16rem,1fr))]
        gap-4
        px-4 sm:px-1
        justify-items-center
        max-w-[72rem]
      "
    >
      {TempsList.map((temp, index) => (
        <div
          key={index}
          className="w-[16rem] border-2 border-gray-300 p-2 rounded-lg"
        >
          <img
            src={temp.imgUrl}
            alt={temp.name}
            className="max-h-80 w-full object-contain"
          />
        </div>
      ))}
    </div>
  </div>
);

};


export default InvoicesTemps
