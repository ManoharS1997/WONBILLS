const HighlightText = ({ children }) => (
    <span className="bg-[#ffed66] px-1 py-0.5 rounded-md boder text-center">{children}</span>
);

export default HighlightText;