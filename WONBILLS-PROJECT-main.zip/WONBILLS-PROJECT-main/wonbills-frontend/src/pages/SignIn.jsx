import SigninForm from "../components/UI-Components/Forms/SignIn/SigninForm";

const SignIn = () => {
  return (
    <div
      className="
        min-h-screen
        w-full
        bg-cover bg-center
        flex flex-col
        items-center
        justify-center
        relative
        px-4
        py-10
      "
      style={{ backgroundImage: "url('/images/bglogin.png')" }}
    >
      {/* FORM */}
      <SigninForm />

      {/* FOOTER TAGLINE */}
      <p className="mt-6 text-sm sm:text-base font-bold text-gray-700">
        #OneclickwithWonBills
      </p>
    </div>
  );
};

export default SignIn;
