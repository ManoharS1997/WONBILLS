import React from "react";
import SignupForm from "../components/UI-Components/Forms/SignUp/SignupForm";

const SignUp = () => {
  return (
    <div
      className="
        min-h-screen
        w-full
        bg-cover bg-center
        flex
        items-center
        justify-center
        px-4
        py-10
      "
      style={{ backgroundImage: "url('/images/bglogin.png')" }}
    >
      <SignupForm />
    </div>
  );
};

export default SignUp;
