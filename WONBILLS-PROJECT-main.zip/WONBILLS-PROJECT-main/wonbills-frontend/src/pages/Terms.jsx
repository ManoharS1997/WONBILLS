import React from 'react'
import Policy from '../components/UI-Components/Terms/Policy';
import Header from '../components/UI-Components/Terms/Header';
import Footer from '../components/UI-Components/LandingPage/Footer';

const Terms = () => {
  return (
    <div className="w-full flex flex-col gap-3">
      <Header />

      <section className="w-full flex justify-center px-3 sm:px-6">
        <Policy />
      </section>

      <Footer />
    </div>
  );
};


export default Terms
