import React from 'react';
import Header from '../components/UI-Components/LandingPage/Header';
import Hero from '../components/UI-Components/LandingPage/Hero';
import Features from '../components/UI-Components/LandingPage/Features';
import InvoicesTemps from '../components/UI-Components/LandingPage/InvoicesTemps';
import Footer from '../components/UI-Components/LandingPage/Footer';

const Landing = () => {
  return (
     <div className="w-full relative overflow-x-hidden">
      <Header />
      <Hero />
      <Features />
      <InvoicesTemps />
      <Footer />
    </div>
  )
}

export default Landing
