import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: true,
    port: 5173,
    strictPort: true,

    allowedHosts: [
      'wonbills.com',
      'www.wonbills.com',
      'test.wonbills.com',   // ✅ FIXED (comma)
      'dev.wonbills.com'     // ✅ correct
    ]
  }
})
